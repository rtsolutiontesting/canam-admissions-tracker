
import { Type } from "@google/genai";
import { User } from "./types";

export const GEMINI_MODEL = 'gemini-3-flash-preview';

export const MOCK_USERS: User[] = [
  { id: '1', email: 'super@edusync.com', role: 'SUPER_ADMIN', lastLogin: new Date().toISOString() },
  { id: '2', email: 'admin@edusync.com', role: 'ADMIN', lastLogin: new Date().toISOString() },
  { id: '3', email: 'viewer@edusync.com', role: 'VIEWER', lastLogin: new Date().toISOString() },
];

export const EXTRACTION_SYSTEM_INSTRUCTION = `You are a professional University Admissions Data Specialist. 
Your task is to extract specific admissions details from university webpage content.

RULES:
1. Extract exactly: intakeOffered, intakeStatus, applicationDeadline, casDeadline, i20Deadline, admissionAlerts.
2. If a value is missing or unclear, return "NOT_FOUND".
3. Use strict JSON output.
4. No markdown, no explanations.
5. Max 500 characters per field.
6. For intakeStatus, choose ONLY from: "open", "closed", "waitlist", "NOT_FOUND".
7. For deadlines, try to extract specific dates.`;

export const EXTRACTION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    intakeOffered: { type: Type.STRING },
    intakeStatus: { type: Type.STRING },
    applicationDeadline: { type: Type.STRING },
    casDeadline: { type: Type.STRING },
    i20Deadline: { type: Type.STRING },
    admissionAlerts: { type: Type.STRING },
  },
  required: ["intakeOffered", "intakeStatus", "applicationDeadline", "casDeadline", "i20Deadline", "admissionAlerts"],
};

export const MOCK_SHEET_DATA: any[] = [
  { sr: "1", universityName: "University of Oxford", country: "UK", location: "Oxford", programName: "MSc in Computer Science", admissionsPageUrl: "https://www.ox.ac.uk/", admissionsEmail: "grad@ox.ac.uk", intakeOffered: "Fall 2024", intakeStatus: "open" },
  { sr: "2", universityName: "Stanford", country: "USA", location: "California", programName: "MS AI", admissionsPageUrl: "https://stanford.edu/", admissionsEmail: "grad@stanford.edu", intakeOffered: "Fall 2024", intakeStatus: "closed" },
  { sr: "3", universityName: "U of T", country: "Canada", location: "Toronto", programName: "MEng", admissionsPageUrl: "https://utoronto.ca/", admissionsEmail: "grad@utoronto.ca", intakeOffered: "", intakeStatus: "" }
];
