
export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'VIEWER';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  lastLogin: string;
}

export interface ProgramRow {
  sr: string;
  universityName: string;
  country: string;
  location: string;
  programName: string;
  admissionsPageUrl: string;
  admissionsEmail: string;
  notes: string;
  intakeOffered?: string;
  intakeStatus?: string;
  applicationDeadline?: string;
  casDeadline?: string;
  i20Deadline?: string;
  admissionAlerts?: string;
  lastChecked?: string;
  extractionStatus?: 'PENDING' | 'FETCHING' | 'EXTRACTING' | 'COMPARING' | 'SUCCESS' | 'FETCH_ERROR';
}

export interface ExtractedData {
  intakeOffered: string;
  intakeStatus: 'open' | 'closed' | 'waitlist' | 'NOT_FOUND';
  applicationDeadline: string;
  casDeadline: string;
  i20Deadline: string;
  admissionAlerts: string;
}

export enum DiffType {
  UNCHANGED = 'UNCHANGED',
  CHANGED = 'CHANGED',
  NEW = 'NEW',
  LOST = 'LOST'
}

export interface CellChange {
  field: keyof ExtractedData;
  oldValue: string;
  newValue: string;
  diffType: DiffType;
}

export interface SyncOperation {
  id: string;
  timestamp: string;
  totalRows: number;
  processedRows: number;
  errors: number;
  status: 'IDLE' | 'RUNNING' | 'COMPLETED' | 'FAILED';
}
