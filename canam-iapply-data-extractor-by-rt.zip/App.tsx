
import React, { useState, useMemo } from 'react';
import { User, UserRole, ProgramRow, SyncOperation, ExtractedData, DiffType, CellChange } from './types';
import { geminiService } from './services/geminiService';
import { generateBatchUpdatePayload, getSheetTabUrl } from './services/sheetsService';
import { MOCK_SHEET_DATA, MOCK_USERS } from './constants';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'admin' | 'schedule'>('dashboard');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  
  // Dashboard States
  const [sheetUrl, setSheetUrl] = useState('https://docs.google.com/spreadsheets/d/1A2B3C4D5E6F7G8H9I0J/edit');
  const [rows, setRows] = useState<ProgramRow[]>(MOCK_SHEET_DATA);
  const [currentTabUrl, setCurrentTabUrl] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncOperation>({ id: '', timestamp: '', totalRows: 0, processedRows: 0, errors: 0, status: 'IDLE' });
  const [logs, setLogs] = useState<string[]>([]);
  const [isGoogleAuthOk, setIsGoogleAuthOk] = useState(true);
  const [scheduleTime, setScheduleTime] = useState('02:00');

  const addLog = (msg: string) => setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev].slice(0, 50));

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = MOCK_USERS.find(u => u.email === emailInput);
    if (user && passwordInput === 'admin123' || (user?.role === 'VIEWER' && passwordInput === 'viewer123')) {
      setCurrentUser(user);
    } else {
      alert("Invalid credentials. Try super@edusync.com (admin123) or viewer@edusync.com (viewer123)");
    }
  };

  const isAuthorized = (roles: UserRole[]) => currentUser && roles.includes(currentUser.role);

  const handleSync = async () => {
    if (!isAuthorized(['SUPER_ADMIN', 'ADMIN'])) {
      alert("Permission denied. You must be an Admin to run syncs.");
      return;
    }
    const spreadsheetId = sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/)?.[1] || 'mock-id';
    const dailyTabName = `Sync-${new Date().toISOString().split('T')[0]}`;
    
    setSyncStatus({ ...syncStatus, status: 'RUNNING', totalRows: rows.length, processedRows: 0 });
    addLog(`Initiating ${dailyTabName} sync...`);
    
    const simulatedTabId = 987654321;
    setCurrentTabUrl(getSheetTabUrl(spreadsheetId, simulatedTabId));

    const updatedRows = [...rows];
    for (let i = 0; i < updatedRows.length; i++) {
      const row = updatedRows[i];
      setRows(prev => prev.map((r, idx) => idx === i ? { ...r, extractionStatus: 'FETCHING' } : r));
      await new Promise(r => setTimeout(r, 600));
      
      const extracted: ExtractedData = {
        intakeOffered: "Winter 2025",
        intakeStatus: "open",
        applicationDeadline: "March 15, 2025",
        casDeadline: "July 2025",
        i20Deadline: "NOT_FOUND",
        admissionAlerts: "Limited seats available."
      };

      updatedRows[i] = { ...row, ...extracted, extractionStatus: 'SUCCESS', lastChecked: new Date().toISOString() };
      setRows([...updatedRows]);
      setSyncStatus(prev => ({ ...prev, processedRows: i + 1 }));
      addLog(`Updated ${row.universityName}`);
    }
    setSyncStatus(prev => ({ ...prev, status: 'COMPLETED' }));
    addLog("Daily snapshot complete.");
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 bg-[url('https://images.unsplash.com/photo-1541339907198-e08756ebafe3?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
        <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl p-8 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600"></div>
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-lg shadow-indigo-200">
              <i className="fas fa-university text-white text-3xl"></i>
            </div>
            <h1 className="text-2xl font-black text-gray-900">Canam Iapply</h1>
            <p className="text-gray-500 text-sm">Data Extractor by RT</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Email Address</label>
              <input 
                type="email" required value={emailInput} onChange={e => setEmailInput(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm transition-all"
                placeholder="super@edusync.com"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Password</label>
              <input 
                type="password" required value={passwordInput} onChange={e => setPasswordInput(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm transition-all"
                placeholder="••••••••"
              />
            </div>
            <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 transition-all active:scale-[0.98]">
              Sign In to System
            </button>
          </form>
          <div className="mt-6 text-center text-xs text-gray-400">
            Powered by Gemini AI Studio & Google Sheets API v4
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-900 flex flex-col">
        <div className="p-6 border-b border-gray-800 flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center">
            <i className="fas fa-university text-white text-sm"></i>
          </div>
          <span className="text-white font-black tracking-tight">CANAM <span className="text-indigo-500">IAPPLY</span></span>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button onClick={() => setActiveTab('dashboard')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'text-gray-400 hover:bg-gray-800'}`}>
            <i className="fas fa-chart-line w-5 text-center"></i> Dashboard
          </button>
          {isAuthorized(['SUPER_ADMIN']) && (
            <button onClick={() => setActiveTab('admin')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'admin' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-800'}`}>
              <i className="fas fa-user-shield w-5 text-center"></i> Admin Panel
            </button>
          )}
          {isAuthorized(['SUPER_ADMIN', 'ADMIN']) && (
            <button onClick={() => setActiveTab('schedule')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'schedule' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-800'}`}>
              <i className="fas fa-clock w-5 text-center"></i> Scheduler
            </button>
          )}
        </nav>

        <div className="p-4 border-t border-gray-800">
          <div className="bg-gray-800/50 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">
              {currentUser.email[0].toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-black text-white truncate">{currentUser.email}</p>
              <p className="text-[10px] text-indigo-400 font-bold tracking-widest">{currentUser.role.replace('_', ' ')}</p>
            </div>
          </div>
          <button onClick={() => setCurrentUser(null)} className="mt-4 w-full text-xs text-gray-500 hover:text-white font-bold transition-colors">
            Logout Session
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 h-16 px-8 flex items-center justify-between shadow-sm z-10">
          <h2 className="text-lg font-bold text-gray-900 capitalize">{activeTab}</h2>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isGoogleAuthOk ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
              <span className="text-xs font-bold text-gray-500">Google API: {isGoogleAuthOk ? 'Authorized' : 'Disconnected'}</span>
            </div>
            <div className="h-6 w-px bg-gray-100"></div>
            <span className="text-xs text-gray-400 font-medium">By RT | v2.4.0</span>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-8 bg-gray-50/50">
          {activeTab === 'dashboard' && (
            <div className="grid grid-cols-12 gap-8 h-full">
              {/* Controls */}
              <div className="col-span-4 space-y-6 h-fit">
                <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                  <h3 className="text-sm font-black text-gray-900 mb-4 uppercase tracking-tighter">Workflow Control</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase">Target Master Sheet URL</label>
                      <input 
                        type="text" value={sheetUrl} onChange={e => setSheetUrl(e.target.value)}
                        className="w-full mt-1 px-4 py-2 bg-gray-50 border border-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    {currentTabUrl && (
                      <a href={currentTabUrl} target="_blank" className="flex items-center justify-center gap-2 w-full py-2 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors">
                        <i className="fas fa-external-link-alt"></i> Open Daily Snapshot
                      </a>
                    )}
                    <button 
                      onClick={handleSync}
                      disabled={syncStatus.status === 'RUNNING' || !isAuthorized(['SUPER_ADMIN', 'ADMIN'])}
                      className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 shadow-md transition-all ${
                        syncStatus.status === 'RUNNING' ? 'bg-gray-100 text-gray-400' : 'bg-indigo-600 hover:bg-indigo-700 text-white active:scale-95'
                      }`}
                    >
                      <i className={`fas ${syncStatus.status === 'RUNNING' ? 'fa-spinner fa-spin' : 'fa-play-circle'}`}></i>
                      {syncStatus.status === 'RUNNING' ? 'Processing Engine...' : 'Run Manual Sync'}
                    </button>
                    {currentUser.role === 'VIEWER' && (
                      <p className="text-[10px] text-center text-amber-600 font-bold bg-amber-50 py-1 rounded">Read-Only Mode Enabled</p>
                    )}
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col h-[400px]">
                  <h3 className="text-sm font-black text-gray-900 mb-4 uppercase tracking-tighter">Live Execution Stream</h3>
                  <div className="flex-1 overflow-y-auto font-mono text-[10px] space-y-2 pr-2">
                    {logs.map((log, i) => (
                      <div key={i} className="text-gray-600 border-l-2 border-indigo-200 pl-3 py-1 bg-indigo-50/30 rounded-r">{log}</div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Grid Preview */}
              <div className="col-span-8 bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
                <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                   <span className="text-xs font-black uppercase text-gray-400 tracking-widest">Master Data Preview</span>
                   <div className="flex gap-4">
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-blue-500"></div><span className="text-[9px] font-bold text-gray-500">CHANGED</span></div>
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-green-500"></div><span className="text-[9px] font-bold text-gray-500">NEW</span></div>
                      <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-red-500"></div><span className="text-[9px] font-bold text-gray-500">LOST</span></div>
                   </div>
                </div>
                <div className="flex-1 overflow-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="sticky top-0 bg-white border-b border-gray-100 z-10 text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
                      <tr>
                        <th className="px-4 py-3">University</th>
                        <th className="px-4 py-3">Program</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Deadline</th>
                        <th className="px-4 py-3">Log</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {rows.map((row, i) => (
                        <tr key={i} className="hover:bg-gray-50/80 transition-colors">
                          <td className="px-4 py-3 font-bold text-gray-900">{row.universityName}</td>
                          <td className="px-4 py-3 text-gray-500 font-medium">{row.programName}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-[4px] font-black text-[9px] uppercase ${row.intakeStatus === 'open' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                              {row.intakeStatus || 'PENDING'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-gray-400 font-mono italic">{row.applicationDeadline || '-'}</td>
                          <td className="px-4 py-3">
                            {row.extractionStatus === 'FETCHING' ? <i className="fas fa-spinner fa-spin text-indigo-500"></i> : <i className="fas fa-check-circle text-green-400"></i>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'admin' && (
            <div className="max-w-4xl mx-auto space-y-8">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8">
                <h3 className="text-xl font-black text-gray-900 mb-6">User Management Panel</h3>
                <div className="overflow-hidden border border-gray-100 rounded-xl">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 text-xs font-black text-gray-400 uppercase tracking-widest border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4">User Email</th>
                        <th className="px-6 py-4">Access Role</th>
                        <th className="px-6 py-4">Last Login</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {MOCK_USERS.map(u => (
                        <tr key={u.id} className="hover:bg-gray-50/50">
                          <td className="px-6 py-4 font-bold text-gray-700">{u.email}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded-lg text-[10px] font-black tracking-wider ${
                              u.role === 'SUPER_ADMIN' ? 'bg-purple-100 text-purple-700' : 
                              u.role === 'ADMIN' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-500'
                            }`}>
                              {u.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-xs text-gray-400">{new Date(u.lastLogin).toLocaleDateString()}</td>
                          <td className="px-6 py-4 text-right">
                            <button className="text-gray-400 hover:text-indigo-600 transition-colors mr-3"><i className="fas fa-edit"></i></button>
                            {u.role !== 'SUPER_ADMIN' && <button className="text-gray-400 hover:text-red-600 transition-colors"><i className="fas fa-trash-alt"></i></button>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-indigo-900 rounded-2xl p-8 text-white shadow-xl flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-black mb-2">Google Cloud Authorization</h3>
                  <p className="text-indigo-200 text-sm max-w-lg">The system uses a Google Cloud Service Account to perform batch updates on the Master sheet. Ensure the Service Account Email is shared on the Sheet with 'Editor' rights.</p>
                </div>
                <button onClick={() => setIsGoogleAuthOk(!isGoogleAuthOk)} className={`px-8 py-3 rounded-xl font-bold transition-all ${isGoogleAuthOk ? 'bg-green-500 text-white shadow-lg shadow-green-900/40' : 'bg-white text-indigo-900'}`}>
                  {isGoogleAuthOk ? 'Authenticated' : 'Link Service Account'}
                </button>
              </div>
            </div>
          )}

          {activeTab === 'schedule' && (
            <div className="max-w-2xl mx-auto space-y-8">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8">
                <div className="flex items-center gap-4 mb-8">
                   <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center">
                     <i className="fas fa-clock text-xl"></i>
                   </div>
                   <div>
                     <h3 className="text-xl font-black text-gray-900">Automation Scheduler</h3>
                     <p className="text-sm text-gray-500 font-medium">Configure daily admissions crawls.</p>
                   </div>
                </div>
                
                <div className="space-y-6">
                  <div className="p-4 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-between">
                    <div>
                      <p className="font-black text-gray-900 text-sm">Enable Daily Cron Job</p>
                      <p className="text-xs text-gray-400 font-medium">Automatic sync will run every day at specified time.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>

                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase mb-2 tracking-widest">Execution Time (GMT)</label>
                    <input 
                      type="time" value={scheduleTime} onChange={e => setScheduleTime(e.target.value)}
                      className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-2xl font-black text-indigo-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white border border-gray-100 p-4 rounded-xl">
                      <p className="text-[10px] font-black text-gray-400 uppercase">Last Run Outcome</p>
                      <p className="text-lg font-black text-green-500">SUCCESS</p>
                      <p className="text-[10px] text-gray-400">Nov 22, 02:00 AM</p>
                    </div>
                    <div className="bg-white border border-gray-100 p-4 rounded-xl">
                      <p className="text-[10px] font-black text-gray-400 uppercase">Next Scheduled Run</p>
                      <p className="text-lg font-black text-indigo-600">TODAY, {scheduleTime}</p>
                      <p className="text-[10px] text-gray-400">Est. duration: 12 min</p>
                    </div>
                  </div>

                  <button className="w-full py-4 bg-gray-900 hover:bg-black text-white font-black rounded-2xl shadow-xl transition-all active:scale-95">
                    Save Schedule Changes
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

const StatusBadge: React.FC<{status?: string}> = ({ status }) => {
  switch (status) {
    case 'FETCHING': return <span className="flex items-center gap-1 text-[11px] font-bold text-blue-500 uppercase"><i className="fas fa-spinner fa-spin"></i> Syncing</span>;
    case 'SUCCESS': return <span className="flex items-center gap-1 text-[11px] font-bold text-green-500 uppercase"><i className="fas fa-check-circle"></i> Recorded</span>;
    case 'FETCH_ERROR': return <span className="flex items-center gap-1 text-[11px] font-bold text-red-500 uppercase"><i className="fas fa-exclamation-triangle"></i> Failed</span>;
    default: return <span className="text-[11px] font-bold text-gray-300 uppercase">Waiting</span>;
  }
}

export default App;
