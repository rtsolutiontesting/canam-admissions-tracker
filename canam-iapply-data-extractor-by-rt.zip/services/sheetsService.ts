
import { CellChange, DiffType, ExtractedData } from "../types";

/**
 * Generates the URL for a specific tab (sheet) within a Google Spreadsheet.
 */
export const getSheetTabUrl = (spreadsheetId: string, sheetId: number) => {
  return `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit#gid=${sheetId}`;
};

/**
 * Simulated request to create a new sheet (tab) for the daily record.
 */
export const generateCreateSheetRequest = (title: string) => {
  return {
    addSheet: {
      properties: {
        title: title,
        gridProperties: {
          rowCount: 1000,
          columnCount: 20
        }
      }
    }
  };
};

/**
 * In a real production environment, this would use 'googleapis' and a Service Account.
 * Since we are in a frontend React environment, we simulate the request generation.
 */
export const generateBatchUpdatePayload = (
  spreadsheetId: string,
  sheetId: number,
  rowIndex: number,
  changes: CellChange[]
) => {
  const requests: any[] = [];

  changes.forEach((change) => {
    // Determine column index based on field mapping
    // Sr(0), Univ(1), Country(2), Loc(3), Program(4), URL(5), Email(6), Notes(7)
    // New Fields start at col 8: IntakeOffered(8), Status(9), Deadline(10), CAS(11), I20(12), Alerts(13)
    const fieldMap: Record<string, number> = {
      intakeOffered: 8,
      intakeStatus: 9,
      applicationDeadline: 10,
      casDeadline: 11,
      i20Deadline: 12,
      admissionAlerts: 13
    };

    const columnIndex = fieldMap[change.field];
    if (columnIndex === undefined) return;

    // Color logic
    let color = { red: 0, green: 0, blue: 0 };
    let bold = false;

    switch (change.diffType) {
      case DiffType.CHANGED:
        color = { red: 0, green: 0, blue: 0.8 }; // BLUE
        bold = true;
        break;
      case DiffType.NEW:
        color = { red: 0, green: 0.6, blue: 0 }; // GREEN
        break;
      case DiffType.LOST:
        color = { red: 0.8, green: 0, blue: 0 }; // RED
        break;
      default:
        color = { red: 0, green: 0, blue: 0 }; // BLACK
    }

    requests.push({
      updateCells: {
        range: {
          sheetId: sheetId,
          startRowIndex: rowIndex,
          endRowIndex: rowIndex + 1,
          startColumnIndex: columnIndex,
          endColumnIndex: columnIndex + 1
        },
        rows: [
          {
            values: [
              {
                userEnteredValue: { stringValue: change.newValue },
                userEnteredFormat: {
                  textFormat: {
                    foregroundColor: color,
                    bold: bold
                  }
                }
              }
            ]
          }
        ],
        fields: "userEnteredValue,userEnteredFormat.textFormat"
      }
    });
  });

  // Always update lastChecked (Column 14)
  requests.push({
    updateCells: {
      range: {
        sheetId: sheetId,
        startRowIndex: rowIndex,
        endRowIndex: rowIndex + 1,
        startColumnIndex: 14,
        endColumnIndex: 15
      },
      rows: [
        {
          values: [
            {
              userEnteredValue: { stringValue: new Date().toISOString() }
            }
          ]
        }
      ],
      fields: "userEnteredValue"
    }
  });

  return { spreadsheetId, requests };
};
