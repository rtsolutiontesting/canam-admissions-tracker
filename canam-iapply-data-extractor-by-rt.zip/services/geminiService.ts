
import { GoogleGenAI } from "@google/genai";
import { EXTRACTION_SYSTEM_INSTRUCTION, EXTRACTION_SCHEMA, GEMINI_MODEL } from "../constants";
import { ExtractedData } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async extractAdmissionsData(url: string, htmlSnippet: string): Promise<ExtractedData> {
    try {
      const response = await this.ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: `URL: ${url}\n\nCONTENT SNIPPET:\n${htmlSnippet}`,
        config: {
          systemInstruction: EXTRACTION_SYSTEM_INSTRUCTION,
          responseMimeType: "application/json",
          responseSchema: EXTRACTION_SCHEMA as any,
        },
      });

      const text = response.text || '';
      return JSON.parse(text) as ExtractedData;
    } catch (error) {
      console.error("Gemini Extraction Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
